The plotting code is rerun each time the slider is moved.
The title only updates when the slider is moved.
