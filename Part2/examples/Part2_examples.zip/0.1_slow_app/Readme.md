Shiny application with multiple inputs.

The code to calculate the point size on the plot using the slider value is slow.
Every time any of the inputs is changed the slow code executes.

