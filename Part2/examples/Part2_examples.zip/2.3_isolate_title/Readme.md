The plotting code is rerun each time the slider is moved or the 'Update title'
button is pressed.
