The plotting code is rerun each time the slider is moved or the text field is
updated.
