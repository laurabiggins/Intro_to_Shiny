library(shiny)

# Extract duplicated code and put it into a reactive expression

ui <- fluidPage(

    titlePanel("Exercise"),
    br(),

    sidebarLayout(
        
        sidebarPanel(
            sliderInput("slider_x_range",
                "Select range for x",
                min = -100,
                max = 100,
                value = c(-10,10))
            ),
                
        mainPanel(
            tabsetPanel(
                tabPanel("x squared", plotOutput("x_squared", width = 400, height = 400)),
                tabPanel("x cubed", plotOutput("x_cubed", width = 400, height = 400))
            )
        )
    )    
)


server <- function(input, output) {

    
    x_values <- reactive(input$slider_x_range[1]:input$slider_x_range[2])
    
    
    output$x_squared <- renderPlot({

        plot(x_values()^2, type = "l")
        
    })
    
    output$x_cubed <- renderPlot({
        
        plot(x_values()^3, type = "l")
        
    })
}

# Run the application 
shinyApp(ui = ui, server = server)
